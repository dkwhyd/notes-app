import React, { useState } from 'react';

export default function NotesForm({ inititialData }) {
  const [notes, setNotes] = useState(inititialData);

  const handleSubmit = (e) => {
    e.preventDefault();
    setNotes([...notes]);
  };

  return (
    <div>
      <h3>Form</h3>
      <form onSubmit={handleSubmit}>
        <br />
        <input type="submit" value="Submit" />
      </form>
    </div>
  );
}
