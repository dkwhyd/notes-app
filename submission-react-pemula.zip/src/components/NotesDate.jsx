import React from 'react';

export default function NotesDate({ date }) {
  return <p className="card-date">{date}</p>;
}
