import React from 'react';

export default function NotesTitle({ title }) {
  return <h3 className="card-title">{title}</h3>;
}

NotesTitle.defaultProps = {
  title: 'judul',
};
