import React from 'react';

export default function Button({
  value, type, onClick, className, status,
}) {
  return (
    <input
      type={type}
      value={value}
      onClick={onClick}
      className={className}
      disabled={status}
    />
  );
}

Button.defaultProps = {
  type: 'button',
  onClick: () => null,
  status: false,
};
