import React from 'react';
import Button from './Button';
import NotesBody from './NotesBody';
import NotesDate from './NotesDate';
import NotesTitle from './NotesTitle';

export default function NotesCard({
  title,
  date,
  body,
  otherNameHandler,
  otherHandler,
  deleteHandler,
}) {
  return (
    <div key={title} className="card">
      <NotesTitle title={title} />
      <NotesDate date={date} />
      <NotesBody body={body} />
      <Button value="Delete" onClick={deleteHandler} className="delete" />
      <Button value={otherNameHandler} onClick={otherHandler} className="archive" />
    </div>
  );
}
