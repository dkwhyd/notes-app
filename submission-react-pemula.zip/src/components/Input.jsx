import React from 'react';

export default function Input({
  label,
  value,
  type,
  placeholder,
  handleChange,
}) {
  return (
    <label htmlFor="input">
      {label}
      <input
        type={type}
        id="input"
        value={value}
        placeholder={placeholder}
        onChange={handleChange}
      />
    </label>
  );
}

Input.defaultProps = {
  type: 'text',
  placeholder: 'ketik disini',
};
