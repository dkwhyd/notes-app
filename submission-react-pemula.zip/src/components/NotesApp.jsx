import React from 'react';
import { Provider } from 'react-redux';
import Notes from './Notes';
import store from '../App/store';

export default function NotesApp() {
  return (
    <div>
      <Provider store={store}>
        <Notes />
      </Provider>
    </div>
  );
}
