import React from 'react';

export default function NotesBody({ body }) {
  return <p className="card-body">{body}</p>;
}
