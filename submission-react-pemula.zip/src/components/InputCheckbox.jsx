import React from 'react';

export default function InputCheckbox({ value, onChange }) {
  return (
    <label htmlFor="myCheckbox">
      <input
        type="checkbox"
        id="myCheckbox"
        checked={value}
        onChange={onChange}
      />
      Archive
    </label>
  );
}
