import React from 'react';

export default function InputTitle({ value, handleChangeTitle }) {
  return (
    <label htmlFor="title" className="title">
      Title
      <input
        id="title"
        type="text"
        placeholder="title"
        value={value}
        onChange={handleChangeTitle}
      />
    </label>
  );
}
