import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { showFormattedDate } from '../utils';
import Button from './Button';
import Input from './Input';
import InputBody from './InputBody';
import InputCheckbox from './InputCheckbox';
import NotesCard from './NotesCard';

function Notes() {
  const noteState = useSelector((state) => state.notes);
  const dispatch = useDispatch();
  const [query, setQuery] = useState('');
  const [error, setError] = useState({
    title: '',
    body: '',
  });
  const maxTitleLength = 50;

  const [form, setForm] = useState({
    id: +new Date(),
    title: '',
    body: '',
    archived: false,
    createdAt: '',
  });

  const handleChange = (fields, e) => {
    setForm({
      ...form,
      [fields]: e.target.value,
    });

    setError({ ...error, title: `karakter tersisa ${maxTitleLength - form.title.length}` });

    if (form.title.length > 50) {
      setError({ ...error, title: 'Judul catatan tidak boleh melebihi 50 karakter' });
    }
  };

  const handleSubmit = (e) => {
    const createdAt = new Date().toISOString();
    e.preventDefault();
    if (form.title.length < 1) {
      setError({ ...error, title: 'Title is empty' });
    } else if (form.body < 1) {
      setError({ ...error, body: 'Message is empty' });
    } else if (form.title.length > 50) {
      setError({ ...error, title: 'Judul catatan tidak boleh melebihi 50 karakter' });
    } else {
      setError({ ...error, title: '', body: '' });
      dispatch({
        type: 'ADD_NOTE',
        title: form.title,
        body: form.body,
        archived: form.archived,
        createdAt,
      });
      // clear form
      setForm({
        title: '',
        body: '',
        archived: false,
        createdAt: '',
      });
    }
  };

  const filteredNotes = noteState.filter(
    (note) => note.title.toLowerCase().includes(query.toLowerCase())
      || note.body.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div>
      <h1>Notes App</h1>
      <div>
        <form onSubmit={handleSubmit} className="form">
          <Input
            label="Title"
            value={form.title}
            placeholder="title"
            handleChange={(e) => handleChange('title', e)}
          />
          {error.title && <div className="error">{error.title}</div> }
          <InputBody
            value={form.body}
            handleChangeBody={(e) => handleChange('body', e)}
          />
          {error.body && <div className="error">{error.body}</div> }

          <InputCheckbox
            value={form.archived}
            onChange={(e) => setForm({ ...form, archived: e.target.checked })}
          />

          <Button value="Add Note" type="submit" className="submit" />
        </form>
      </div>

      <div className="searchContainer">
        <Input
          label="Find Notes"
          value={query}
          placeholder="type title or notes"
          handleChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div>
        <h2>Catatan Aktif</h2>
        <div className="notesContainer">
          {filteredNotes.filter((note) => !note.archived).length === 0 ? (
            <div className="data-not-found">
              <p>Tidak ada catatan</p>
            </div>
          ) : (
            filteredNotes
            && filteredNotes
              .filter((note) => !note.archived)
              .map((note) => (
                <NotesCard
                  id={note.id}
                  key={note.id}
                  date={showFormattedDate(note.createdAt)}
                  title={note.title}
                  body={note.body}
                  deleteHandler={() => dispatch({
                    type: 'REMOVE_NOTE',
                    id: note.id,
                  })}
                  otherNameHandler="Archived"
                  otherHandler={() => dispatch({
                    type: 'ARCHIVE_NOTE',
                    id: note.id,
                  })}
                />
              ))
          )}
        </div>
      </div>

      <div>
        <h2>Archived</h2>
        <div className="archivedContainer">
          {filteredNotes.filter((note) => note.archived === true).length
          === 0 ? (
            <div className="data-not-found">
              <p>Tidak ada catatan</p>
            </div>
            ) : (
              filteredNotes
            && filteredNotes
              .filter((note) => note.archived === true)
              .map((note) => (
                <NotesCard
                  id={note.id}
                  key={note.id}
                  date={showFormattedDate(note.createdAt)}
                  title={note.title}
                  body={note.body}
                  deleteHandler={() => dispatch({
                    type: 'REMOVE_NOTE',
                    id: note.id,
                  })}
                  otherNameHandler="Unarchived"
                  otherHandler={() => dispatch({
                    type: 'UNARCHIVED_NOTE',
                    id: note.id,
                  })}
                />
              ))
            )}
        </div>
      </div>
    </div>
  );
}

export default Notes;
